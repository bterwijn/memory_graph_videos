import memory_graph as mg

a = (4, 3, 2)
b = a
a += (1,)

print(f'{a=}\n{b=}')
